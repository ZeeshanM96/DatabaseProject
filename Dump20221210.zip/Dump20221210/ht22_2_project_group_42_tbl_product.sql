CREATE DATABASE  IF NOT EXISTS `ht22_2_project_group_42` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ht22_2_project_group_42`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: ht22_2_project_group_42
-- ------------------------------------------------------
-- Server version	5.6.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_product`
--

DROP TABLE IF EXISTS `tbl_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_product` (
  `ProductID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductTitle` varchar(45) NOT NULL,
  `ProductDescription` varchar(45) NOT NULL,
  `RetailPriceWithoutTax` int(11) NOT NULL,
  `ValueAddedTaxPercenatge` int(11) NOT NULL,
  `DiscountPercentage` int(11) DEFAULT NULL,
  `FeaturedProduct` tinyint(4) NOT NULL,
  `StockQuantity` int(11) NOT NULL,
  `DepartmentID` int(11) NOT NULL,
  PRIMARY KEY (`ProductID`),
  KEY `DepartmentID` (`DepartmentID`),
  KEY `INDX_tbl_product` (`ProductTitle`),
  CONSTRAINT `tbl_product_ibfk_1` FOREIGN KEY (`DepartmentID`) REFERENCES `tbl_department` (`DepartmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_product`
--

LOCK TABLES `tbl_product` WRITE;
/*!40000 ALTER TABLE `tbl_product` DISABLE KEYS */;
INSERT INTO `tbl_product` VALUES (1,'Lenovo','Lenovo ThinkPad Corei5 8th Gen',3000,10,2,0,5,6),(2,'Dell','Dell Latitude Corei3 6th Gen',2500,8,18,1,10,6),(3,'Desktop 1','Desktop 1 Corei3 6th Gen',3500,12,0,0,10,5),(4,'Desktop 2','Desktop 2 Corei5 8th Gen',5500,15,30,1,10,5),(5,'IPad Mini','Apple IPad Mini',5000,5,0,0,10,7),(6,'Tab 2','Samsung tablet Curve',4000,10,45,1,12,7),(7,'KeyBoard','RGB keyboard QWERTY',1200,5,0,0,20,11),(8,'Mouse','A4tech Wireless Mouse',1300,2,50,0,15,11),(9,'Laptop Charger','Dell Charger',600,0,0,0,10,12),(10,'Ethernet Cable','Ethernet Cable 10 inches',300,0,10,1,15,12),(11,'Covers','Folding Cover Protector',150,0,0,0,10,13),(12,'Cable','Geniuine C-type Charging Cable',50,0,75,1,30,13),(13,'Samsung Tv','48\" Oled Display',15000,20,0,0,10,9),(14,'Sony Tv','55\" retina display',20000,22,5,1,10,9),(15,'Mitsubishi','FD730U Projector, DLP, Brightness: 4100 Lumen',3000,8,0,0,5,10),(16,'Acer','QH11 LCD LED projector 720p 200 lumens',2800,13,67,1,6,10);
/*!40000 ALTER TABLE `tbl_product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-10 16:58:33
