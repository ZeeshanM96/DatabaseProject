CREATE DATABASE  IF NOT EXISTS `ht22_2_project_group_42` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ht22_2_project_group_42`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: ht22_2_project_group_42
-- ------------------------------------------------------
-- Server version	5.6.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_department`
--

DROP TABLE IF EXISTS `tbl_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_department` (
  `DepartmentID` int(11) NOT NULL AUTO_INCREMENT,
  `DepartmentTitle` varchar(150) NOT NULL,
  `DepartmentDescription` varchar(255) NOT NULL,
  `ManagedBy` int(11) DEFAULT NULL,
  PRIMARY KEY (`DepartmentID`),
  KEY `ManagedBy` (`ManagedBy`),
  KEY `INDX_tbl_department` (`DepartmentTitle`),
  CONSTRAINT `tbl_department_ibfk_1` FOREIGN KEY (`ManagedBy`) REFERENCES `tbl_department` (`DepartmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_department`
--

LOCK TABLES `tbl_department` WRITE;
/*!40000 ALTER TABLE `tbl_department` DISABLE KEYS */;
INSERT INTO `tbl_department` VALUES (1,'IKEA ','WELCOME TO THE IKEA STORE OF SWEDEN. HAVE A NICE DAY',NULL),(2,'Electronics','Electronics Store',1),(3,'Computers and tablets','This is Computers and tablets Store. Under ELECTRONICS Store.',2),(4,'TV and video','This is TV and video Store. Under ELECTRONICS Store.',2),(5,'Desktops','This is Desktops Store. Under Computers and tablets Store.',3),(6,'Laptops','This is Laptops Store. Under Computers and tablets Store.',3),(7,'Tablets','This is Tablets Store. Under Computers and tablets Store.',3),(8,'Accessories','This is Accessories Store. Under Computers and tablets Store.',3),(9,'TVs','This is TVs Store. Under TV and video Store.',4),(10,'Projectors','This is Projectors Store. Under TV and video Store.',4),(11,'For desktops','This is For desktops Store. Under Accessories Store.',8),(12,'For laptops ','This is For laptops Store. Under Accessories Store.',8),(13,'For tablets','This is For tablets Store. Under Accessories Store.',8),(14,'Furniture','This is Furniture Store.',1),(15,'Home Furniture','This is Home Furniture Store. Under Furniture Store.',14),(16,'Office Furniture','This is Office Furniture Store. Under Furniture Store.',14),(17,'Fancy Furniture','This is Fancy Furniture Store. Under Furniture Store.',14),(18,'Random Things','This is Random Things Store. Under Electronic Store',2);
/*!40000 ALTER TABLE `tbl_department` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-10 16:58:30
